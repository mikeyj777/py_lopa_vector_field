from pypws.enums import Phase, VesselConditions, ResultCode
from pypws.entities import FlashResult

from py_lopa.calcs.consts import Consts

consts = Consts()

class Vessel_Dimension_Specification:

    # for vessels containing two-phases, the option for homogenous two-phase vessel was originally not available in PWS.
    # there is an option available currently, but it isn't included in the VesselCondions enum.  It is hard-coded here as "2".

    # will return empty dictionary if conditions aren't appropriate.
    # e.g. flash result liqid, but vapor specified in user inputs

    # for cases with "vessel_vol_multiplier" equal to 2, this is 
    # where the model is generating a pseudo-vessel.  The PHAST interface 
    # calculates that it is a 2-phase system, so the pseudo-vessel will be 
    # twice as large as needed, and the targeted leak phase will be released 
    # (liquid from btm, vapor from top)

    # MJ - 9/5/24 - with pws 4, the option for homogenous is explicitly called out in the vessel conditions enumeration.  
    # This is reflected below.  the hard-coded "2" values for "vc"(vessel conditions) have been replaced with "VesselConditions.HOMOGENEOUS_VESSEL_TYPE".

    def __init__(self, mi, flashResult:FlashResult):

        self.mi = mi
        self.mi_rp = self.mi.RELIEF_PHASE
        self.rp_enum = consts.RELIEF_PHASE
        self.fr = flashResult
        self.fl_ph = self.fr.fluid_phase

        self.specs = {}
        self.rho_kgm3 = -1
        self.leak_height_fract_of_vessel = -1
        self.vc = -1
        self.liquid_fill_fract = -1
        self.vessel_vol_multiplier = -1

        phase_output = self.fl_ph
        if isinstance(phase_output, int):
            phase_output = Phase(phase_output).name
        print(f'vds.  requested phase: {consts.RELIEF_PHASE(self.mi_rp).name} | flash result phase: {phase_output}')

    def get_specs(self):

        if self.mi_rp == self.rp_enum.VAPOR:
            if self.fl_ph == Phase.VAPOUR:
                self.mi_rp_vapor__fr_vapor()
            if self.fl_ph == Phase.TWO_PHASE:
                self.mi_rp_vapor__fr_2_phase()

        if self.mi_rp == self.rp_enum.TWO_PHASE:
            if self.fl_ph == Phase.VAPOUR:
                self.mi_rp_2_phase__fr_vapor()
            if self.fl_ph == Phase.TWO_PHASE:
                self.mi_rp_2_phase__fr_2_phase()
            if self.fl_ph == Phase.LIQUID:
                self.mi_rp_2_phase__fr_liquid()

        if self.mi_rp == self.rp_enum.LIQUID:
            if self.fl_ph == Phase.TWO_PHASE:
                self.mi_rp_liquid__fr_2_phase()
            if self.fl_ph == Phase.LIQUID:
                self.mi_rp_liquid__fr_liquid()
        
        if self.mi_rp == self.rp_enum.LET_MODEL_DECIDE:
            if self.fl_ph == Phase.VAPOUR:
                self.mi_rp_lmd__fr_vapor()
            if self.fl_ph == Phase.TWO_PHASE:
                self.mi_rp_lmd__fr_2_phase()
            if self.fl_ph == Phase.LIQUID:
                self.mi_rp_lmd__fr_liquid() 
        
        if len(self.specs) > 0:
            self.rho_kgm3 = self.specs['rho_kgm3']
            self.leak_height_fract_of_vessel = self.specs['leak_height_fract_of_vessel']
            self.vc = self.specs['vc']
            self.liquid_fill_fract = self.specs['liquid_fill_fract']
            self.vessel_vol_multiplier = self.specs['vessel_vol_multiplier']

            return ResultCode.SUCCESS
        
        return ResultCode.FAIL_EXECUTION

    
    def mi_rp_vapor__fr_vapor(self):
        self.specs = {
            'rho_kgm3': self.fr.vapour_density,
            'leak_height_fract_of_vessel': 0,
            'vc': VesselConditions.PURE_GAS,
            'liquid_fill_fract': 0,
            'vessel_vol_multiplier': 1
        }
    
    def mi_rp_vapor__fr_2_phase(self):
        
        # if the system is two-phase, but the user specified a vapor release,
        # the model will pad with nitrogen until its state is pure vapor.

        

        self.specs = {
            'rho_kgm3': self.fr.vapour_density,
            'leak_height_fract_of_vessel': 0,
            'vc': VesselConditions.PURE_GAS,
            'liquid_fill_fract': 0,
            'vessel_vol_multiplier': 1
        }

    
    def mi_rp_2_phase__fr_vapor(self):
        
        # if user specifies 2-phase, but actual state is not, there is 
        # no current allowance to specify liquid fraction from the target table interface.
        # we will simply model release from actual phase without any adjustment

        self.specs = {
            'rho_kgm3': self.fr.vapour_density,
            'leak_height_fract_of_vessel': 0,
            'vc': VesselConditions.PURE_GAS,
            'liquid_fill_fract': 0,
            'vessel_vol_multiplier': 1
        }
    
    def mi_rp_2_phase__fr_2_phase(self):

        ll = self.get_liquid_level()

        # prev version used a stratified two phase vessel.  However, homogenous is more appropriate.  Testing the difference

        # previous

        # self.specs = {
        #     'rho_kgm3': self.fr.total_fluid_density,
        #     'leak_height_fract_of_vessel': 0,
        #     'vc': VesselConditions.STRATIFIED_TWO_PHASE_VESSEL,
        #     'liquid_fill_fract': ll,
        #     'vessel_vol_multiplier': 1
        # }

        
        # correct
        self.specs = {
            'rho_kgm3': self.fr.total_fluid_density,
            'leak_height_fract_of_vessel': 0,
            'vc': VesselConditions.HOMOGENEOUS_VESSEL_TYPE,
            'liquid_fill_fract': ll,
            'vessel_vol_multiplier': 1
        }



    def mi_rp_2_phase__fr_liquid(self):

        # if user specifies 2-phase, but actual state is not, there is 
        # no current allowance to specify liquid fraction.
        # we will simply model release from actual phase without any adjustment


        self.specs = {
            'rho_kgm3': self.fr.liquid_density,
            'leak_height_fract_of_vessel': 0.98,
            'vc': VesselConditions.PRESSURIZED_LIQUID_VESSEL,
            'liquid_fill_fract': 0.99,
            'vessel_vol_multiplier': 1/0.99
        }
    
    def mi_rp_liquid__fr_2_phase(self):
        
        # if user specifies liquid, but model is currently two-phase,
        # the model will attempt to drop the temperautre a few degrees to
        # try to adjust state to pure liquid.  if that doesn't work, it will raise an
        # exception.
        # here, it is assumed that the state should be liquid.

        ll = self.get_liquid_level()
        
        if ll == 0:
            ll = 0.01

        self.specs = {
            'rho_kgm3': self.fr.liquid_density,
            'leak_height_fract_of_vessel': 0.99*ll,
            'vc': VesselConditions.PRESSURIZED_LIQUID_VESSEL,
            'liquid_fill_fract': ll,
            'vessel_vol_multiplier': 1
        }

    def mi_rp_liquid__fr_liquid(self):

        self.specs = {
            'rho_kgm3': self.fr.liquid_density,
            'leak_height_fract_of_vessel': 0.98,
            'vc': VesselConditions.PRESSURIZED_LIQUID_VESSEL,
            'liquid_fill_fract': 0.99,
            'vessel_vol_multiplier': 1/0.99
        }
    
    def mi_rp_lmd__fr_vapor(self):
        self.specs = {
            'rho_kgm3': self.fr.vapour_density,
            'leak_height_fract_of_vessel': 0,
            'vc': VesselConditions.PURE_GAS,
            'liquid_fill_fract': 0,
            'vessel_vol_multiplier': 1
        }

    def mi_rp_lmd__fr_2_phase(self):
        
        # if the user allows the model to determine which phase is appropriate,
        # and the model identifies that it is two-phase, it is most likely a system with a 
        # distinct liquid and vapor separation in the vessel.  
        # the model will treat it as a release from the liquid portion of the two-phase release

        ll = self.get_liquid_level()

        if ll == 0:
            ll = 0.01
        
        self.specs = {
            'rho_kgm3': self.fr.total_fluid_density,
            'leak_height_fract_of_vessel': 0.99*ll,
            'vc': VesselConditions.HOMOGENEOUS_VESSEL_TYPE,
            'liquid_fill_fract': ll,
            'vessel_vol_multiplier': 1
        }
    
    def mi_rp_lmd__fr_liquid(self):
        self.specs = {
            'rho_kgm3': self.fr.liquid_density,
            'leak_height_fract_of_vessel': 0.98,
            'vc': VesselConditions.PRESSURIZED_LIQUID_VESSEL,
            'liquid_fill_fract': 0.99,
            'vessel_vol_multiplier': 1/0.99
        }

    def get_liquid_level(self):

        mass_basis_kg = 100
        liquid_dens_kg_m3 = self.fr.liquid_density
        liq_mass_kg = mass_basis_kg * self.fr.liquid_mass_fraction
        liq_vol_m3 = liq_mass_kg / liquid_dens_kg_m3
        vap_mass_kg = mass_basis_kg - liq_mass_kg
        vap_vol_m3 = vap_mass_kg / self.fr.vapour_density
        tot_vol_m3 = liq_vol_m3 + vap_vol_m3
        liq_level = liq_vol_m3 / tot_vol_m3

        return min(0.99, liq_level)