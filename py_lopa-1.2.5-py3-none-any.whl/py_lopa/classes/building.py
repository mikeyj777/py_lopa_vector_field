import copy
import math
import numpy as np
import pandas as pd
from statistics import NormalDist

from py_lopa.calcs.consts import Consts, Wx_Enum
from py_lopa.calcs import helpers
from py_lopa.calcs.flattening import Flattening
from py_lopa.classes.toxicological_analysis import Toxicological_Analysis

cd = Consts().CONSEQUENCE_DATA

class Building:

    def __init__(self, occupancy=pd.NA, num=pd.NA, dist_m=pd.NA, ht_m=pd.NA, ach=pd.NA, hvac_shutoff_min=pd.NA, nighttime_occupancy = pd.NA, use_one_met_condition_worst_case = True, use_dose_and_probit = False):
        self.occupancy = occupancy
        self.num = num
        self.dist_m = dist_m
        self.ht_m = ht_m
        self.ach = ach
        self.nighttime_occupancy = nighttime_occupancy
        self.conc_pfls = []
        self.hvac_shutoff_sec = hvac_shutoff_min
        self.indoor_and_outdoor_conc_vs_time_for_all_durations_and_hazard_types_df = pd.DataFrame()
        if self.hvac_shutoff_sec is not pd.NA:
            self.hvac_shutoff_sec *= 60
        
        res = {
            Wx_Enum.NIGHT: {},
            Wx_Enum.DAY: {}
        }

        if use_one_met_condition_worst_case:
            res = {
                cd.WX_WORST_CASE: {}
            }

        self.building_conseq_targets = {}
        self.building_conseq_result_dict = copy.deepcopy(res)
        self.use_dose_and_probit = use_dose_and_probit
            
    def prep_targ_dicts(self, use_one_met_condition_worst_case, wx_enum, hazard_type):

        haz = hazard_type
        
        self.building_conseq_targets[haz] = {}

        base_targs = {
            cd.CAT_MINOR: pd.NA,
            cd.CAT_MODERATE: pd.NA
        }

        occ_to_higher_conseq_cat = {
            cd.KEYS_BLDG_UNOCCUPIED: cd.CAT_SERIOUS,
            cd.KEYS_BLDG_LOW_OCC: cd.CAT_SERIOUS,
            cd.KEYS_BLDG_MED_OCC: cd.CAT_CRITICAL,
            cd.KEYS_BLDG_HIGH_OCC: cd.CAT_CATASTROPHIC
        }

        occ_to_use = copy.deepcopy(self.occupancy)

        if not use_one_met_condition_worst_case and wx_enum == Wx_Enum.NIGHT:
            occ_to_use = copy.deepcopy(self.nighttime_occupancy)

        self.building_conseq_targets[haz] = copy.deepcopy(base_targs)
        self.building_conseq_targets[haz][occ_to_higher_conseq_cat[occ_to_use]] = pd.NA

    
    def set_conseq_targs(self, haz_type, analysis_df):
        
        haz_df = analysis_df[analysis_df[cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL] == haz_type]
        haz_df = haz_df[haz_df[cd.CLASS_TITLE] == cd.CLASS_BLDG]

        for cat in self.building_conseq_targets[haz_type]:
            row = haz_df[haz_df[cd.CAT_TITLE] == cat]
            crit = helpers.get_data_from_pandas_series_element(row[cd.CONC_VOLF_TITLE])
            self.building_conseq_targets[haz_type][cat] = crit
            

    def set_conseq_results(self, conc_pfls, use_one_met_condition_worst_case, wx_enum, hazard_type, duration_sec, chems):

        # self.chemicals_of_greatest_hazard_and_their_vapor_volf[cd.HAZARD_TYPE_INHALATION] = {
        #             cd.WORST_CASE_CHEM_INDEX: worst_shi_idx,
        #             cd.CONC_VOLF_TITLE: molf_worst_shi
        #         }

        self.chem_of_greatest_hazard_vapor_volf_dose_and_probit_consts = chems.chem_of_greatest_hazard_vapor_volf_dose_and_probit_consts

        haz = hazard_type
        self.conc_pfls = conc_pfls
        conc_in_bldg = 0
        self.ta = chems.ta
        ans = self.get_conc_dose_and_prob_in_bldg()
        if ans is not None:
            indoor_concentration_over_time = ans['conc_and_tox_profile']
            indoor_concentration_over_time['duration_sec'] = duration_sec
            indoor_concentration_over_time['hazard_type'] = hazard_type
            indoor_concentration_over_time['weather_condition'] = wx_enum
            self.indoor_and_outdoor_conc_vs_time_for_all_durations_and_hazard_types_df = pd.concat([self.indoor_and_outdoor_conc_vs_time_for_all_durations_and_hazard_types_df, indoor_concentration_over_time], ignore_index = True)
            conc_in_bldg = ans['max_conc_indoor_volf']
            slot_dose_above_threshold = ans['slot_dose_above_threshold']
            prob_sev_inj_above_threshold = ans['probability_of_severe_injury_above_threshold']
        haz_targs_dict = self.building_conseq_targets[haz]
        self.building_conseq_result_dict[wx_enum][haz] = pd.NA
        if not use_one_met_condition_worst_case and wx_enum == Wx_Enum.NIGHT and self.nighttime_occupancy == cd.KEYS_BLDG_UNOCCUPIED:
            return
        for i in range(len(cd.CAT_ALL_CATEGORIES)-1,-1,-1):
            cat = cd.CAT_ALL_CATEGORIES[i]
            if cat in haz_targs_dict.keys():
                if pd.isna(haz_targs_dict[cat]):
                    continue
                if conc_in_bldg >= haz_targs_dict[cat]:
                    if self.use_dose_and_probit and haz == cd.HAZARD_TYPE_INHALATION:
                        if not (slot_dose_above_threshold or prob_sev_inj_above_threshold):
                            continue
                    self.building_conseq_result_dict[wx_enum][haz] = cat
                    break

    def get_conc_dose_and_prob_in_bldg(self):
        flat_proj = Flattening(conc_pfls=self.conc_pfls)

        ht_m = self.ht_m
        tol = Consts.ELEVATION_RANGE_FOR_CONC_EVAL_M

        min_ht_m = max(0, ht_m - tol)
        max_ht_m = ht_m + tol

        conc_at_bldg = flat_proj.calc_max_conc_at_dist(self.dist_m, min_ht_m, max_ht_m)

        if conc_at_bldg == 0:
            return None

        ach = self.ach

        hvac_sec = self.hvac_shutoff_sec

        # perform infiltration analysis to determine conc inside occupied building
        # a conservative estimate is that flow with air handlers active ("ach_forced") will be 4x 
        # the measured rate without air handlers running (ach_natural).

        # max value for ach is specified in "Consts.MAX_ACH"

        ans = self.ta.building_infiltration_analysis(conc_outside = conc_at_bldg, ach_forced = 4*ach, ach_natural = ach, max_time_to_cutoff_airhandler_sec = hvac_sec)

        return ans