from py_lopa.data.exception_enum import Exception_Enum

class Vessel_Overpressure_Methodology:

    def __init__(self, mi, flash_data) -> None:
        self.mi = mi
        self.mawp_pa = mi.MAWP_PA
        self.pressure_factor = None
        if self.mawp_pa is not None:
            self.set_pressure_factor()
        self.flash_data = flash_data

    def set_pressure_factor(self):

        # pressure factor based on overage in terms of gauge pressure
        mawp_gauge = self.mawp_pa + 101325
        sys_press_gauge = self.mi.PRESS_PA + 101325
        self.pressure_factor = sys_press_gauge / mawp_gauge

    def guidance(self):
        if self.pressure_factor >= 1 and self.pressure_factor < 1.3:
            self.pressure_factor_1_to_1_3_x_MAWP()
        if self.pressure_factor >= 1.3 and self.pressure_factor < 2:
            self.pressure_factor_1_3_to_2_x_MAWP()
        if self.pressure_factor >= 2:
            self.pressure_factor_at_least_2_x_MAWP()

    def pressure_factor_1_to_1_3_x_MAWP(self):
        if self.mi.MAX_HOLE_SZ_M is None:
            raise Exception(Exception_Enum.RELEASE_DIAMETER_NOT_PROVIDED)
        self.mi.CATASTROPHIC_VESSEL_FAILURE = False
    
    def pressure_factor_1_3_to_2_x_MAWP(self):
        self.mi.CATASTROPHIC_VESSEL_FAILURE = False
        self.mi.MAX_HOLE_SZ_M = 0.5 / 12 / 3.28084 # half-inch leak
    
    def pressure_factor_at_least_2_x_MAWP(self):
        # liquid full = leak at input rate (requires rate to have been entered)
        
        if self.mi.RELIEF_CALC_RATE_KG_S is None:
            raise Exception(Exception_Enum.RELEASE_RATE_NOT_PROVIDED)

    

