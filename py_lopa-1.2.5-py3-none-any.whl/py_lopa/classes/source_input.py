import numpy as np
import pandas as pd

from py_lopa.calcs import helpers
from py_lopa.phast_io import phast_prep
from py_lopa.calcs import thermo_pio
from py_lopa.calcs.consts import Consts
from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.classes.phys_props import Phys_Props

cd = Consts().CONSEQUENCE_DATA

class Source_Input:

    def __init__(self, description = '', mass_flow_kg_s=0, mass_composition=[], temp_k = 298.15, press_pa = 101325, chem_mix = [], enthalpy_j_s = None, specific_enthalpy_j_kg = None, pws_flashresult = None, pylopa_flashresult = None, cheminfo = None, mws = [], molfs = [], pws_material=None, mi=None, dynamic_df = None):
        self.mi = mi
        self.description = description
        self.mass_flow_kg_s = mass_flow_kg_s
        self.mass_composition = mass_composition
        self.temp_k = temp_k
        self.press_pa = press_pa
        self.chem_mix = chem_mix
        self.enthalpy_j_s = enthalpy_j_s
        self.specific_enthalpy_j_kg = specific_enthalpy_j_kg
        self.pws_flashresult = pws_flashresult
        self.pylopa_flashresult = pylopa_flashresult
        self.cheminfo = cheminfo
        self.mws = mws
        self.molfs = molfs
        self.pws_material = pws_material
        self.integ_cps_at_ref_temp = None
        self.phys_props_dict = {}
        self.integ_cps = None
        self.py_lopa_flash = None
        self.log_handler = print
        if self.mi is not None:
            self.log_handler = mi.LOG_HANDLER
            if self.cheminfo is None:
                self.cheminfo = self.mi.chems.cheminfo
        if self.cheminfo is None:
            self.cheminfo = helpers.get_cheminfo()
        self.dynamic_df = dynamic_df

    def populate_flash_results(self, temp_k = None, flash_calc = None):

        if temp_k is None:
            temp_k = self.temp_k
        
        self.mws = helpers.get_mws(chem_mix=self.chem_mix, cheminfo=self.cheminfo)

        self.molfs = helpers.mol_fracts_from_mass_fracts(self.mass_composition, mws=self.mws)

        if flash_calc is None:
            flash_calc = thermo_pio.ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=self.chem_mix, mws = self.mws, overall_molfs=self.molfs, temp_K=temp_k, press_Pa=self.press_pa, cheminfo=self.cheminfo)
        self.py_lopa_flash = flash_calc

        self.build_component_dataframe()

    def generate_pws_material(self):
        cheminfo = self.cheminfo
        chem_mix = self.chem_mix
        mass_comp = self.mass_composition
        mat_ids = helpers.get_material_ids(chem_mix=chem_mix, cheminfo = cheminfo)
        self.mws = helpers.get_mws(chem_mix=chem_mix, cheminfo=cheminfo)
        self.molfs = helpers.mol_fracts_from_mass_fracts(masses=mass_comp, mws=self.mws)
        chem_names = helpers.get_chem_names(chems_list=chem_mix, cheminfo=cheminfo)
        self.pws_material = phast_prep.prep_material(chems=None, chem_names=chem_names, mat_ids = mat_ids, release_molfs = self.molfs)
        
    def get_flashes_for_source_input(self, lf, temp_k):
        
        temp_to_use = self.temp_k
        if temp_k is not None:
            temp_to_use = temp_k
        state = phast_prep.prep_state(
            press_pa=self.press_pa, 
            temp_K=temp_to_use, 
            lf=lf, 
            use_multicomponent_modeling=self.mi.USE_MULTICOMPONENT_METHOD
        )
        flash = phast_prep.flash_calc(state=state, material=self.pws_material)
        self.pws_flashresult = flash
        # if lf is not None:
        #     temp_to_use = flash.temperature
    
    def build_component_dataframe(self, py_lopa_flash = None, mass_flow_kg_s = None, temp_k = None):
        
        if py_lopa_flash is None:
            py_lopa_flash = self.py_lopa_flash
            if temp_k is None:
                temp_k = py_lopa_flash['temp_k']
        
        if temp_k is None:
            temp_k = self.temp_k

        if mass_flow_kg_s is None:
            mass_flow_kg_s = self.mass_flow_kg_s

        xs = py_lopa_flash['xs']
        ys = py_lopa_flash['ys']
        vf = py_lopa_flash['vf']

        mws_np = np.array(self.mws)
        mass_fracts = helpers.normalize_fractions(self.mass_composition)
        mass_fracts_np = np.array(mass_fracts)

        mass_rates_kg_s_np = mass_fracts_np * mass_flow_kg_s
        mole_rates_kmol_s_np = mass_rates_kg_s_np / mws_np
        
        tot_molar_flow_kmol_s = mole_rates_kmol_s_np.sum()

        liquid_mole_rates_kmol_s = np.array(xs) * tot_molar_flow_kmol_s * (1-vf)
        vapor_mole_rates_kmol_s = np.array(ys) * tot_molar_flow_kmol_s * (vf)

        component_data = []
        
        for i in range(len(self.chem_mix)):

            x_moles_i = liquid_mole_rates_kmol_s[i]
            y_moles_i = vapor_mole_rates_kmol_s[i]

            component_data.append({
                'source_description': self.description,
                'cas_no': self.chem_mix[i],
                'temp_k': temp_k,
                'press_pa': self.press_pa,
                'x_moles_start': x_moles_i,
                'y_moles_start': y_moles_i,
                'tot_moles_x_and_y': x_moles_i + y_moles_i,
                'x_integ_cp_start': None,
                'y_integ_cp_start': None,
                'x_moles_final': None,
                'y_moles_final': None,
                'x_integ_cp_final': None,
                'y_integ_cp_final': None,
                'heat_of_vaporization_j_kmol': None,
                'heat_of_vaporization_j': None,
                'sensible_heat_j': None,
                'total_enthalpy_change_j': None
            })

        self.component_data_df = pd.DataFrame(component_data)

    def concatenate_component_data_for_mixed_stream(self, source_inputs):
        
        comp_data_df_list = []
        for si in source_inputs:
            comp_data_df_list.append(si.component_data_df)

        self.component_data_df = pd.concat(comp_data_df_list, ignore_index=True)
        self.component_data_df.reset_index()
