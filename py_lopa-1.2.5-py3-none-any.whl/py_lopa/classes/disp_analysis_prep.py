import numpy as np
import pandas as pd

from py_lopa.calcs.consts import Consts
from py_lopa.data.tables import Tables
import py_lopa.calcs.helpers as helpers
from py_lopa.classes.building import Building

cd = Consts().CONSEQUENCE_DATA

class Disp_Analysis_Prep:

    def __init__(self, mi, chems):
       
        self.analysis_list = []
        self.mi = mi
        self.chems = chems
        self.bldgs = mi.bldgs
        self.conc_basis_for_higher_conseqs = -1

        if mi.VALID_HAZARDS[cd.HAZARD_TYPE_FLASH_FIRE]:
            self.set_conseq_crit(cd.HAZARD_TYPE_FLASH_FIRE)
        if mi.VALID_HAZARDS[cd.HAZARD_TYPE_INHALATION]:
            self.set_conseq_crit(cd.HAZARD_TYPE_INHALATION)

        self.analysis_df = pd.DataFrame(self.analysis_list, columns=[
            cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL,
            cd.KEYS_TARG_AND_TYPE_CLASS,
            cd.KEYS_TARG_AND_TYPE_CATEGORY,
            cd.KEYS_TARG_AND_TYPE_DIST_M,
            cd.KEYS_TARG_AND_TYPE_CONC_VOLF,
            cd.KEYS_TARG_AND_TYPE_BLDG_NUM,
            cd.KEYS_TARG_AND_TYPE_BLDG_DIST_M,
            cd.KEYS_TARG_AND_TYPE_BLDG_HEIGHT_M,
            cd.KEYS_TARG_AND_TYPE_BLDG_ACH,
            cd.KEYS_TARG_AND_TYPE_BLDG_HVAC_SHUTOFF_SEC,
            cd.KEYS_TARG_AND_TYPE_RESULTS_DIST_M,
            cd.KEYS_TARG_AND_TYPE_RESULTS_CONC_VOLF,
            cd.KEYS_TARG_AND_TYPE_RESULTS_QUALIFIED_RESULT
        ])

    def set_conseq_crit(self, hazard_type):

        targ_concs = []
        the_table = ''
        if hazard_type == cd.HAZARD_TYPE_FLASH_FIRE:
            targ_concs.append(self.chems.flam_loc)
            the_table = Tables().FLASH_FIRE_CONSEQUENCE_CRITERIA
        if hazard_type == cd.HAZARD_TYPE_INHALATION:
            targ_concs = self.chems.inhalation_locs
            the_table = Tables().INHALATION_CONSEQUENCE_CRITERIA

        df = helpers.get_dataframe_from_csv(the_table)
        class_col_title = cd.CLASS_TITLE
        for _, row in df.iterrows():
            curr_class = row[class_col_title]
            for conseq_cat in cd.CAT_ALL_CATEGORIES:

                criteria = row[conseq_cat]
                conc_volf = pd.NA
                #create empty building with pd.NA for all properties
                bldg = Building()

                # criteria is either in terms of distance (stored in ft) from release or conc threshold
                # that is, if a cloud goes over a certain distance to lfl, it meets that conseq criteria
                # if it is conc based, then if it goes above a certain concentration either onsite, offsite 
                # or within a bldg, then it meets the conseq criteria.
                
                if curr_class == cd.CLASS_BLDG:
                    bldg = self.get_bldg_details(conseq_cat)

                crit = {}

                if hazard_type == cd.HAZARD_TYPE_FLASH_FIRE:
                    crit = self.set_ff_conseq_crit(cd, curr_class, criteria, targ_concs[0])

                if hazard_type == cd.HAZARD_TYPE_INHALATION:
                    crit = self.set_inhal_conseq_crit(cd, curr_class, criteria, targ_concs)

                conc_volf = crit[cd.KEYS_TARG_AND_TYPE_CONC_VOLF]
                dist_m = crit[cd.KEYS_TARG_AND_TYPE_DIST_M]

                targ_and_type = {
                        
                    cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL: hazard_type,
                    cd.KEYS_TARG_AND_TYPE_CLASS: curr_class,
                    cd.KEYS_TARG_AND_TYPE_CATEGORY: conseq_cat,
                    cd.KEYS_TARG_AND_TYPE_DIST_M: dist_m,
                    cd.KEYS_TARG_AND_TYPE_CONC_VOLF: conc_volf,
                    cd.KEYS_TARG_AND_TYPE_BLDG_NUM: bldg.num,
                    cd.KEYS_TARG_AND_TYPE_BLDG_DIST_M: bldg.dist_m,
                    cd.KEYS_TARG_AND_TYPE_BLDG_HEIGHT_M: bldg.ht_m,
                    cd.KEYS_TARG_AND_TYPE_BLDG_ACH: bldg.ach,
                    cd.KEYS_TARG_AND_TYPE_BLDG_HVAC_SHUTOFF_SEC: bldg.hvac_shutoff_sec,
                    cd.KEYS_TARG_AND_TYPE_RESULTS_DIST_M: pd.NA,
                    cd.KEYS_TARG_AND_TYPE_RESULTS_CONC_VOLF: pd.NA,
                    cd.KEYS_TARG_AND_TYPE_RESULTS_QUALIFIED_RESULT: pd.NA

                }  

                self.analysis_list.append(targ_and_type)

    def set_ff_conseq_crit(self, cd, curr_class, criteria, lfl):

        dist_m = pd.NA
        conc_volf = pd.NA

        if criteria <= 10:
            conc_volf = criteria * lfl
            self.conc_basis_for_higher_conseqs = conc_volf
        elif criteria < 1e6:
            conc_volf = criteria * lfl
            if self.conc_basis_for_higher_conseqs > 0:
                conc_volf = self.conc_basis_for_higher_conseqs
                self.conc_basis_for_higher_conseqs = -1
            
            dist_m = criteria / 3.28084
            dist_m = self.get_targ_dist(dist_m = dist_m, curr_class = curr_class)
            if pd.isna(dist_m):
                conc_volf = pd.NA
        
        return {
            cd.KEYS_TARG_AND_TYPE_CONC_VOLF: conc_volf,
            cd.KEYS_TARG_AND_TYPE_DIST_M: dist_m
        }

    def set_inhal_conseq_crit(self, cd, curr_class, criteria, locs):

        dist_m = pd.NA
        conc_volf = pd.NA

        if criteria <=3:
            conc_volf = locs[criteria]
        elif criteria <= 100:
            conc_volf = locs[3] * criteria
            self.conc_basis_for_higher_conseqs = conc_volf
        elif criteria < 1e6:
            conc_volf = locs[3] * criteria
            if self.conc_basis_for_higher_conseqs > 0:
                conc_volf = self.conc_basis_for_higher_conseqs
                self.conc_basis_for_higher_conseqs = -1
            dist_m = criteria / 3.28084
            dist_m = self.get_targ_dist(dist_m = dist_m, curr_class = curr_class)
            if pd.isna(dist_m):
                conc_volf = pd.NA
        
        conc_volf = min(0.999999, conc_volf)

        return {
            cd.KEYS_TARG_AND_TYPE_CONC_VOLF: conc_volf,
            cd.KEYS_TARG_AND_TYPE_DIST_M: dist_m
        }

    def get_bldg_details(self, conseq_cat):
        bldg = self.bldgs[0]
        if conseq_cat == cd.CAT_CRITICAL:
            bldg = self.bldgs[1]
        elif conseq_cat == cd.CAT_CATASTROPHIC:
            bldg = self.bldgs[2]
        else:
            min_dist = np.inf
            min_dist_idx = 0
            for i in range(len(self.bldgs)):
                if pd.isna(self.bldgs[i].dist_m):
                    continue
                if self.bldgs[i].dist_m < min_dist:
                    min_dist = self.bldgs[i].dist_m
                    min_dist_idx = i
            bldg = self.bldgs[min_dist_idx]
            
        return bldg

    def get_targ_dist(self, dist_m, curr_class):

        dist_to_offsite_m = self.mi.CONSEQUENCE_DISTS[cd.KEYS_DIST_TO_OFFSITE_M]
        
        if curr_class == cd.CLASS_ONSITE:
            if dist_m > dist_to_offsite_m:
                dist_m = pd.NA
        
        if curr_class == cd.CLASS_OFFSITE:
            dist_m += dist_to_offsite_m
            
        return dist_m
