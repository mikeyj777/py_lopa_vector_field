import copy
import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from PIL import Image
import io
import datetime
from datetime import datetime as dt

from py_lopa.calcs import helpers 

class Plotter:

    def __init__(self, chems, x, y, cols, run_detail = ''):
        self.chems = chems
        self.x = x
        self.y = y
        self.cols = cols
        self.run_detail = run_detail
        self.plt = plt

    def plot_data(self):
        if self.chems == None:
            self.no_limits_display()
            return 1

        num_plots = 0
        plot_ff = True
        if self.chems.ff_credible:
            num_plots += 1
        if self.chems.inhal_credible:
            num_plots += 1
            plot_ff = False
        if num_plots == 1:
            self.single_plot_display(plot_ff)
            return 1

        self.multi_plot_display()

        return num_plots
            
    def no_limits_display(self):
        cols = self.cols
        x = self.x
        y = self.y
        cols = [max(x,0.01) for x in cols]
        cols = np.log10(cols)
        cmap, norm = mcolors.from_levels_and_colors([-3, -2, -1, 0, 1, 2, 3, 4, 5], ['black', 'red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'])
        self.plt.scatter(x, y, c=cols, cmap=cmap, norm=norm)

    def single_plot_display(self, plot_ff):
        chems = self.chems
        cols = self.cols
        x = self.x
        y = self.y
        level_colors = ['green', 'yellow', 'red']
        if plot_ff:
            title = self.run_detail + '\r\nFlammability Footprint:  25/50/100 pct LFL'
            levels = [
                chems.flam_loc * 0.25,
                chems.flam_loc * 0.50,
                chems.flam_loc
            ]
        else:
            title = self.run_detail + '\r\nInhalation Footprint:  Lev 1/2/3/10xLev 3 Concs'
            levels = [
                chems.inhalation_locs[1],
                chems.inhalation_locs[2],
                chems.inhalation_locs[3],
                10 * chems.inhalation_locs[3]
            ]
            level_colors = ['green', 'yellow', 'red', 'pink']
        cmap, norm = mcolors.from_levels_and_colors(levels, level_colors, extend='max')
        self.plt.scatter(x, y, c=cols, cmap=cmap, norm=norm)
        self.plt.title(title)
        self.plt.xlabel('Downwind Distance (m)')
        self.plt.ylabel('Height above Ground Level (m)')
        
    def multi_plot_display(self):
        chems = self.chems
        cols = self.cols
        x = self.x
        y = self.y

        fig, ax = self.plt.subplots(nrows=2, ncols=1)
        levels = []

        level_colors = []

        titles = [
            self.run_detail + '\r\nInhalation Footprint:  Lev 1/2/3/10xLev 3 Concs',
            self.run_detail + '\r\nFlammability Footprint:  25/50/100 pct LFL'
        ]

        if len(chems.inhalation_locs) > 0:
            levels.append([ 
                    chems.inhalation_locs[1],
                    chems.inhalation_locs[2],
                    chems.inhalation_locs[3],
                    10 * chems.inhalation_locs[3]
                ])
            
            level_colors.append(['green', 'yellow', 'red', 'pink'])
        if chems.flam_loc is not None and chems.flam_loc > 0 and chems.flam_loc < 1e6:
            levels.append([ 
                    chems.flam_loc * 0.25,
                    chems.flam_loc * 0.50,
                    chems.flam_loc
                ])

            level_colors.append(['green', 'yellow', 'red'])

        for i in range(2):
            cmap, norm = mcolors.from_levels_and_colors(levels[i], level_colors[i], extend='max')
            ax[i].scatter(x, y, c=cols, cmap=cmap, norm=norm)
            ax[i].set_title(titles[i])
            ax[i].set_xlabel('Downwind Distance (m)')
            ax[i].set_ylabel('Height above Ground Level (m)')
            ax[i].autoscale()
        

        self.plt.subplots_adjust(hspace=1.0)


    def save_image(self, time_utc=None):
        if time_utc is None:
            time_utc = dt.now(datetime.UTC)
        self.run_detail = str(self.run_detail)
        t_out = helpers.time_stamp_format(time_utc)
        file_nm = 'output/plot_'
        if self.run_detail != '':
            file_nm += self.run_detail + '_'

        file_nm +=  t_out + '.png'
        print(f'dispersion plot stored to {file_nm}')
        self.plt.savefig(file_nm)

    def show_figure(self):
        self.plt.show()

    def get_figure_as_json_dumped_img(self):
        self.get_figure_as_pil_image()
        np_img = np.asarray(self.img)
        list_img = np_img.tolist()
        self.json_list_img = json.dumps(list_img)
        return self.json_list_img

    def get_figure_as_pil_image(self):
        fig = self.plt.gcf()
        buf = io.BytesIO()
        fig.savefig(buf)
        buf.seek(0)
        self.img = Image.open(buf)
        return self.img
