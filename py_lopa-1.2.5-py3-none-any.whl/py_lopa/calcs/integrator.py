import copy
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Union


class Integrator:
    """
    A class for integrating 3D irregular spatial data with concentration values.
    Calculates total mass and various volume metrics using a voxel-based approach.
    """
    
    def __init__(self, x_bins: int = 100, y_bins: int = 100, min_points_per_voxel: int = 1):
        """
        Initialize the integrator with grid resolution and quality control parameters.
        
        Args:
            x_bins: Number of bins in the x direction
            y_bins: Number of bins in the y direction
            min_points_per_voxel: Minimum number of points required in a voxel for it to be included
        """
        self.x_bins = x_bins
        self.y_bins = y_bins
        self.min_points_per_voxel = min_points_per_voxel
        
        # Data storage
        self.data = None
        self.bounds = None
        self.z_levels_m = None
        self.z_spacing_m = None
        self.voxels = None
        
        # Results
        self.total_mass_g = None
        self.total_volume_m3 = None
        self.theoretical_volume_m3 = None
        self.average_density_g_m3 = None
        self.z_level_masses_g = None
        self.effective_voxel_count = None
    
    def load_data(self, df: pd.DataFrame) -> None:
        """
        Load data from a pandas DataFrame.
        The DataFrame should have columns: x, y, z, conc_g_m3
        
        Args:
            df: DataFrame containing spatial concentration data
        """
        required_columns = ['x', 'y', 'z', 'conc_g_m3']
        missing_cols = [col for col in required_columns if col not in df.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")
        
        self.data = copy.deepcopy(df)
        self.calculate_bounds()
    
    def calculate_bounds(self) -> Dict:
        """
        Calculate the spatial bounds of the dataset and organize data by z-level.
        
        Returns:
            Dictionary containing the bounds information
        """
        if self.data is None or len(self.data) == 0:
            raise ValueError("No data loaded")
        
        # Calculate min/max for each dimension
        x_min, x_max = self.data['x'].min(), self.data['x'].max()
        y_min, y_max = self.data['y'].min(), self.data['y'].max()
        z_min, z_max = self.data['z'].min(), self.data['z'].max()
        conc_min, conc_max = self.data['conc_g_m3'].min(), self.data['conc_g_m3'].max()
        
        # Organize data by z level
        data_by_z = self.data.groupby('z')
        z_levels_m = sorted(self.data['z'].unique())
        
        # Store results
        self.bounds = {
            'x': {'min': x_min, 'max': x_max, 'range': x_max - x_min},
            'y': {'min': y_min, 'max': y_max, 'range': y_max - y_min},
            'z': {'min': z_min, 'max': z_max, 'range': z_max - z_min},
            'concentration': {'min': conc_min, 'max': conc_max, 'range': conc_max - conc_min}
        }

        # check for planar dimensions.  add thickness if needed.
        for dim in ['x', 'y', 'z']:
            if self.bounds[dim]['range'] == 0:
                temp_df = copy.deepcopy(self.data)
                temp_df[dim] = temp_df[dim].min() + 0.1
                self.data = pd.concat((self.data, temp_df), ignore_index=True)
        
        # recalculate range
        # Calculate min/max for each dimension
        x_min, x_max = self.data['x'].min(), self.data['x'].max()
        y_min, y_max = self.data['y'].min(), self.data['y'].max()
        z_min, z_max = self.data['z'].min(), self.data['z'].max()
        conc_min, conc_max = self.data['conc_g_m3'].min(), self.data['conc_g_m3'].max()
        
        # Organize data by z level
        data_by_z = self.data.groupby('z')
        z_levels_m = sorted(self.data['z'].unique())
        
        # Store results
        self.bounds = {
            'x': {'min': x_min, 'max': x_max, 'range': x_max - x_min},
            'y': {'min': y_min, 'max': y_max, 'range': y_max - y_min},
            'z': {'min': z_min, 'max': z_max, 'range': z_max - z_min},
            'concentration': {'min': conc_min, 'max': conc_max, 'range': conc_max - conc_min}
        }

        self.bounds['conc_g_m3'] = self.bounds['concentration']
        self.z_levels_m = np.array(z_levels_m)
        
        # Calculate z spacing
        self.calculate_z_spacing()
        
        return self.bounds
    
    def calculate_z_spacing(self) -> Dict:
        """
        Calculate the thickness of each z-level layer.
        
        Returns:
            Dictionary mapping z levels to their respective thicknesses
        """
        if self.z_levels_m is None:
            raise ValueError("Z levels not calculated yet")
        
        self.z_spacing_m = {}
        z_levels = self.z_levels_m
        
        for i, z in enumerate(z_levels):
            if i == 0:
                # Bottom layer
                self.z_spacing_m[z] = z_levels[1] - z
            elif i == len(z_levels) - 1:
                # Top layer
                self.z_spacing_m[z] = z - z_levels[i-1]
            else:
                # Middle layers - average of distances to layers above and below
                self.z_spacing_m[z] = ((z_levels[i+1] - z) + (z - z_levels[i-1])) / 2
        
        return self.z_spacing_m
    
    def integrate(self, 
                  x_min: Optional[float] = None, 
                  x_max: Optional[float] = None,
                  y_min: Optional[float] = None, 
                  y_max: Optional[float] = None,
                  z_min: Optional[float] = None, 
                  z_max: Optional[float] = None) -> Dict:
        """
        Perform the integration over the specified bounds.
        
        Args:
            x_min, x_max: Optional bounds for x dimension
            y_min, y_max: Optional bounds for y dimension
            z_min, z_max: Optional bounds for z dimension
            
        Returns:
            Dictionary containing the integration results
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() first.")
        
        # Set up integration bounds
        integration_bounds = self._prepare_integration_bounds(x_min, x_max, y_min, y_max, z_min, z_max)
        
        # Create voxels and assign data points
        self._create_voxels(integration_bounds)
        
        # Calculate mass and volume for each voxel
        self._calculate_mass_and_volume(integration_bounds)
        
        # Calculate z-level masses
        self.calculate_z_level_masses()
        
        # Package results
        results = {
            'total_mass_g': self.total_mass_g,
            'total_volume_m3': self.total_volume_m3,
            'theoretical_volume_m3': self.theoretical_volume_m3,
            'volume_ratio': self.total_volume_m3 / self.theoretical_volume_m3 if self.theoretical_volume_m3 > 0 else 0,
            'average_density_g_m3': self.average_density_g_m3,
            'effective_voxel_count': self.effective_voxel_count,
            'total_data_points': len(self.data),
            'grid_resolution': {
                'x': self.x_bins,
                'y': self.y_bins,
                'z_levels': len(self.z_levels_m)
            },
            'bounds': integration_bounds
        }
        
        return results
    
    def _prepare_integration_bounds(self, 
                                    x_min: Optional[float], 
                                    x_max: Optional[float],
                                    y_min: Optional[float], 
                                    y_max: Optional[float],
                                    z_min: Optional[float], 
                                    z_max: Optional[float]) -> Dict:
        """
        Prepare the bounds for integration, using data bounds as defaults.
        
        Args:
            x_min, x_max, y_min, y_max, z_min, z_max: Optional custom bounds
            
        Returns:
            Dictionary with the bounds to use for integration
        """
        # Use provided bounds if specified, otherwise use data bounds
        bounds = {
            'x': {
                'min': x_min if x_min is not None else self.bounds['x']['min'],
                'max': x_max if x_max is not None else self.bounds['x']['max']
            },
            'y': {
                'min': y_min if y_min is not None else self.bounds['y']['min'],
                'max': y_max if y_max is not None else self.bounds['y']['max']
            },
            'z': {
                'min': z_min if z_min is not None else self.bounds['z']['min'],
                'max': z_max if z_max is not None else self.bounds['z']['max']
            }
        }
        
        # Calculate ranges
        bounds['x']['range'] = bounds['x']['max'] - bounds['x']['min']
        bounds['y']['range'] = bounds['y']['max'] - bounds['y']['min']
        bounds['z']['range'] = bounds['z']['max'] - bounds['z']['min']
        
        return bounds
    
    def _create_voxels(self, bounds: Dict) -> None:
        """
        Create voxels and assign data points to them.
        
        Args:
            bounds: Dictionary with integration bounds
        """
        x_step = bounds['x']['range'] / self.x_bins
        y_step = bounds['y']['range'] / self.y_bins
        
        self.voxels = {}
        voxel_count = 0
        
        # Filter data within custom bounds if needed
        mask = (
            (self.data['x'] >= bounds['x']['min']) & 
            (self.data['x'] <= bounds['x']['max']) &
            (self.data['y'] >= bounds['y']['min']) & 
            (self.data['y'] <= bounds['y']['max']) &
            (self.data['z'] >= bounds['z']['min']) & 
            (self.data['z'] <= bounds['z']['max'])
        )
        data_to_process = self.data[mask]
        
        # Assign points to voxels
        for _, point in data_to_process.iterrows():
            x_idx = min(int((point['x'] - bounds['x']['min']) / x_step), self.x_bins - 1)
            y_idx = min(int((point['y'] - bounds['y']['min']) / y_step), self.y_bins - 1)
            z = point['z']
            
            voxel_key = f"{x_idx}_{y_idx}_{z}"
            
            if voxel_key not in self.voxels:
                self.voxels[voxel_key] = {
                    'x_idx': x_idx,
                    'y_idx': y_idx,
                    'z': z,
                    'total_conc_g_m3': 0,
                    'count': 0,
                    'average_conc_g_m3': 0
                }
                voxel_count += 1
            
            self.voxels[voxel_key]['total_conc_g_m3'] += point['conc_g_m3']
            self.voxels[voxel_key]['count'] += 1
            self.voxels[voxel_key]['average_conc_g_m3'] = self.voxels[voxel_key]['total_conc_g_m3'] / self.voxels[voxel_key]['count']
    
    def _calculate_mass_and_volume(self, bounds: Dict) -> None:
        """
        Calculate the total mass and volume based on the voxels.
        
        Args:
            bounds: Dictionary with integration bounds
        """
        x_step = bounds['x']['range'] / self.x_bins
        y_step = bounds['y']['range'] / self.y_bins
        
        total_mass_g = 0
        total_volume_m3 = 0
        effective_voxel_count = 0
        
        for voxel_key, voxel in self.voxels.items():
            # Skip voxels with too few points
            if voxel['count'] < self.min_points_per_voxel:
                continue
            
            # Calculate voxel volume (using appropriate z spacing)
            z = voxel['z']
            if z in self.z_spacing_m:
                z_thickness_m = self.z_spacing_m[z]
            else:
                # For custom ranges that might not align with data z levels
                nearest_z = min(self.z_levels_m, key=lambda level: abs(level - z))
                z_thickness_m = self.z_spacing_m[nearest_z]
            
            volume_m3 = x_step * y_step * z_thickness_m
            
            # Calculate mass in this voxel
            avg_concentration_g_m3 = voxel['average_conc_g_m3']
            voxel_mass_g = avg_concentration_g_m3 * volume_m3
            
            total_mass_g += voxel_mass_g
            total_volume_m3 += volume_m3
            effective_voxel_count += 1
        
        # Calculate theoretical volume
        theoretical_volume_m3 = bounds['x']['range'] * bounds['y']['range'] * bounds['z']['range']
        
        # Store results
        self.total_mass_g = total_mass_g
        self.total_volume_m3 = total_volume_m3
        self.theoretical_volume_m3 = theoretical_volume_m3
        self.average_density_g_m3 = total_mass_g / total_volume_m3 if total_volume_m3 > 0 else 0
        self.effective_voxel_count = effective_voxel_count
    
    def calculate_z_level_masses(self) -> List[Dict]:
        """
        Calculate mass distribution by z-level.
        
        Returns:
            List of dictionaries with z-level, mass, and thickness information
        """
        if self.voxels is None:
            raise ValueError("Run integrate() first to generate voxel data")
        
        z_level_masses_g = {z: 0 for z in self.z_levels_m}
        
        # Calculate x and y step sizes
        x_step = self.bounds['x']['range'] / self.x_bins
        y_step = self.bounds['y']['range'] / self.y_bins
        
        # Sum up mass for each Z level
        for voxel in self.voxels.values():
            if voxel['count'] < self.min_points_per_voxel:
                continue
                
            z = voxel['z']
            if z not in z_level_masses_g:
                z_level_masses_g[z] = 0
            
            # Get z thickness
            z_thickness_m = self.z_spacing_m.get(z, 1.0)  # Default if not found
            
            # Calculate voxel mass
            volume_m3 = x_step * y_step * z_thickness_m
            avg_concentration_g_m3 = voxel['total_conc_g_m3'] / voxel['count']
            voxel_mass_g = avg_concentration_g_m3 * volume_m3
            
            z_level_masses_g[z] += voxel_mass_g
        
        # Convert to list of dictionaries
        self.z_level_masses_g = [
            {
                'z_level_m': z,
                'mass_g': mass,
                'thickness_m': self.z_spacing_m.get(z, 1.0)
            }
            for z, mass in z_level_masses_g.items()
        ]
        
        # Sort by z-level
        self.z_level_masses_g.sort(key=lambda x: x['z_level_m'])
        
        return self.z_level_masses_g
    
    def get_summary(self) -> Dict:
        """
        Get a summary of the integration results.
        
        Returns:
            Dictionary with summary statistics
        """
        if self.total_mass_g is None:
            raise ValueError("Run integrate() first to generate results")
        
        return {
            'total_mass_g': self.total_mass_g,
            'average_density_g_m3': self.average_density_g_m3,
            'total_volume_m3': self.total_volume_m3,
            'theoretical_volume_m3': self.theoretical_volume_m3,
            'volume_ratio': self.total_volume_m3 / self.theoretical_volume_m3 if self.theoretical_volume_m3 > 0 else 0,
            'effective_voxel_count': self.effective_voxel_count,
            'grid_resolution': {
                'x_bins': self.x_bins,
                'y_bins': self.y_bins,
                'z_levels': len(self.z_levels_m)
            }
        }


# Example usage:
def example_usage():
    """Example of how to use the IrregularDataIntegrator class."""
    # Create sample data
    import numpy as np
    
    # Create sample data with x, y, z coordinates and concentration values
    np.random.seed(42)
    n = 100
    data = {
        'x': np.linspace(0, n, 101),
        'y': np.linspace(0, n, 101),
        'z': np.linspace(0, n, 101),
    }

    # simulating data for testing simply as the product of each input
    # need to get some data that can be reliably tested against

    data['conc_g_m3'] = None
    df = pd.DataFrame(data)
    
    # Initialize integrator
    integrator = Integrator(x_bins=101, y_bins=101, min_points_per_voxel=1)
    
    # Load data and run integration
    integrator.load_data(df)
    result = integrator.integrate()
    
    # Print results
    print(f"Total mass: {integrator.total_mass_g:.2f} g")
    print(f"Average density: {integrator.average_density_g_m3:.2f} g/m³")
    print(f"Total volume: {integrator.total_volume_m3:.2f} m³")
    print(f"Effective voxel count: {integrator.effective_voxel_count}")
    
    # Get z-level masses
    z_masses = integrator.z_level_masses_g
    print(f"\nMass distribution over {len(z_masses)} Z levels:")
    for i, level in enumerate(z_masses[:5]):  # Show first 5 levels
        print(f"Z = {level['z_level_m']:.1f} m: {level['mass_g']:.2f} g")